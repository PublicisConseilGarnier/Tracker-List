# Garnier Campaign Asset Tracker — v3.0 Pro

A premium single-page SaaS-grade campaign tracker for **Publicis Conseil × Garnier**.  
Built for Nicolas Lefebvre — Multi-campaign · Release Tracking · Kantar scorecards · Box integration · Glass UI.

## 🚀 Deploy to Netlify (60 seconds)

### Option A — Drag & drop (fastest)
1. Go to **https://app.netlify.com/drop**
2. Drag this entire folder (or just `index.html`) onto the page
3. ✅ Done — Netlify gives you a public URL instantly

### Option B — Git + auto-deploy
1. Push this folder to a GitHub repo
2. Connect the repo on Netlify
3. No build command needed — `publish = "."` is set in `netlify.toml`

## ✨ Features (v3.0 Pro)

- **Dashboard** — KPIs with hover effects + 7-point sparkline trends
- **Release Tracking** — agency-level hero counter (X/Y delivered + %), per-campaign progress bars, weekly delta
- **Multi-campaign** — switch, rename, duplicate, delete, new from template
- **Asset versioning** — every status change / edit / delivery is logged in `asset.history`. Click 🕓 to see the full timeline
- **Kantar scorecards** — toggle Kantar on an asset → upload PNG/JPG (drag-drop), preview, lightbox, ESC to close. Images embedded in client PDF
- **Box auto-folders** — one click creates a Box folder named after the GAR-ID (e.g. `GAR-001`) inside a configurable parent folder, with shared link
- **Glass UI + animated aura** — background gradient adapts to the active campaign's category color (green / blue / purple / orange)
- **Dark mode** — full theme toggle
- **Client PDF report** — print-ready OR one-click download via jsPDF + html2canvas, includes Kantar scorecard gallery
- **Supabase sync** — push/pull team data, auto-sync every 30s
- **Weekly recap** — opens mailto with full delivered / late breakdown
- **Auto-flag late** — one click flags overdue assets
- **Export / Import / Reset** — JSON backups

## 🔧 Integrations setup

### Box (per-asset folders)
1. Get a Developer Token at https://app.box.com/developers/console (60-min token)
2. Create or pick a parent folder in Box, copy its ID from the URL
3. In the app → Settings → Box integration → paste both, click Save
4. Edit any asset → Box section → "Create Box folder for GAR-ID"

### Supabase (team sync)
Create a `garnier_tracker_state` table:
```sql
create table garnier_tracker_state (
  id text primary key,
  data jsonb,
  updated_at timestamptz
);
```
Then enable RLS or use the anon key in Settings → Cloud sync.

### SendGrid weekly emails
The "Weekly Recap" button currently opens a `mailto:` with a full text body. For true automated sending, deploy a Netlify Function that proxies to SendGrid (see Claude conversation for boilerplate).

## 🎨 Customization

- **Brand colors** — edit `:root` variables at the top of the `<style>` block in `index.html`
- **Category aura colors** — see `CATEGORY_COLORS` constant in the JS
- **Milestone rules** — see `milestoneFor()` function

## 📦 What's in this folder

| File | Purpose |
|------|---------|
| `index.html` | The whole app (single file, ~110 KB) |
| `netlify.toml` | Netlify config: publish dir + security headers + CSP |
| `README.md` | This file |

## 🆘 Troubleshooting

- **Box API fails with CORS** — Box's PUT endpoint allows browser calls with `Authorization: Bearer`. If you get CORS errors, your token may have expired (60 min) — regenerate it.
- **PDF looks empty** — wait for `html2canvas` to load before clicking. Open the Report page once before clicking Download.
- **Local data lost** — all data lives in `localStorage`. Use Settings → Export JSON regularly, or enable Supabase sync.

---

**Garnier Tracker v3.0 Pro** · Publicis Conseil · 2026  
Built with ❤️ for Nicolas Lefebvre
